import json
from datetime import datetime
import requests
from PIL import Image, ImageTk
from io import BytesIO
import tkinter as tk
from tkinter import messagebox, ttk

def get_current():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def load_from_file():
    try:
        with open("data.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_to_file(history_list):
    with open("data.json", "w") as file:
        json.dump(history_list, file, indent=4)
    print("Data saved successfully!")

def get_next_tax_invoice_no(history_list):
    if not history_list:
        return 1
    return max(record["taxInvoiceNo"] for record in history_list) + 1

def is_valid_promptpay(promptpay):
    return promptpay.isdigit() and len(promptpay) == 10

def display_qr_code(number_promptpay):
    qr_code_url = f"https://promptpay.io/{number_promptpay}.png"
    response = requests.get(qr_code_url)
    img_data = Image.open(BytesIO(response.content))
    img_data = img_data.resize((200, 200), Image.ANTIALIAS)
    return ImageTk.PhotoImage(img_data)

def display_history(history_list):
    history_window = tk.Toplevel()
    history_window.title("History Records")
    history_window.configure(bg="#FFF0F5")

    columns = ("Date", "Tax Invoice No", "User", "PromptPay", "Total Amount", "QR Code")
    tree = ttk.Treeview(history_window, columns=columns, show="headings")
    tree.heading("Date", text="Date")
    tree.heading("Tax Invoice No", text="Tax Invoice No")
    tree.heading("User", text="User")
    tree.heading("PromptPay", text="PromptPay")
    tree.heading("Total Amount", text="Total Amount")
    tree.heading("QR Code", text="QR Code")
    tree.column("Date", width=150)
    tree.column("Tax Invoice No", width=100)
    tree.column("User", width=150)
    tree.column("PromptPay", width=150)
    tree.column("Total Amount", width=100)
    tree.column("QR Code", width=100)

    for record in history_list:
        tree.insert("", "end", values=(record["date"], record["taxInvoiceNo"], record["user"], record["numberPromptPay"], record["totalBath"], "Show QR Code"))

    tree.pack(pady=20)

    def show_qr_code(event):
        item = tree.selection()[0]
        record = tree.item(item, "values")
        qr_code_img = display_qr_code(record[3])
        qr_code_label = tk.Label(history_window, image=qr_code_img, bg="#FFF0F5")
        qr_code_label.image = qr_code_img
        qr_code_label.pack(pady=20)

    tree.bind("<Double-1>", show_qr_code)

    tk.Button(history_window, text="Close", command=history_window.destroy, bg="#FF69B4", fg="#000080").pack(pady=10)

def display_summary(data):
    summary_window = tk.Toplevel()
    summary_window.title("Bill Summary")
    summary_window.configure(bg="#FFF0F5")

    tk.Label(summary_window, text="BillSplitter", font=("Arial", 24), bg="#FFF0F5").pack(pady=10)

    columns = ("Description", "Details")
    tree = ttk.Treeview(summary_window, columns=columns, show="headings")
    tree.heading("Description", text="Description")
    tree.heading("Details", text="Details")
    tree.column("Description", width=150)
    tree.column("Details", width=400)

    tree.insert("", "end", values=("Date", data["date"]))
    tree.insert("", "end", values=("Tax Invoice No", data["taxInvoiceNo"]))
    tree.insert("", "end", values=("User", data["user"]))
    tree.insert("", "end", values=("PromptPay", data["numberPromptPay"]))
    tree.insert("", "end", values=("Number of People", data["numberPeople"]))

    tree.insert("", "end", values=("---------- Menus ---------", "----------"))
    for item, price in data["menuPrice"].items():
        tree.insert("", "end", values=(item, f"{price:.2f} THB"))

    tree.insert("", "end", values=("Discount", f"{data['discount']} THB"))
    tree.insert("", "end", values=("Total (before tax)", f"{data['totalBath']} THB"))
    tree.insert("", "end", values=("Tax", f"{data['taxRate']:.2f}%"))
    tree.insert("", "end", values=("Total (after tax)", f"{data['VATable']} THB"))

    tree.insert("", "end", values=("----- Payment Details ----", "-----"))
    for person, amount in data["personPayment"].items():
        tree.insert("", "end", values=(person, f"{amount:.2f} THB"))

    tree.pack(pady=20)

    qr_code_img = display_qr_code(data["numberPromptPay"])
    qr_code_label = tk.Label(summary_window, image=qr_code_img, bg="#FFF0F5")
    qr_code_label.image = qr_code_img
    qr_code_label.pack(pady=20)

    tk.Button(summary_window, text="Close", command=summary_window.destroy, bg="#FF69B4", fg="#000080").pack(pady=10)

class BillSplitterApp:
    def __init__(self, root):
        self.history_list = load_from_file()
        self.data = {
            "date": "",
            "taxInvoiceNo": get_next_tax_invoice_no(self.history_list),
            "user": "",
            "numberPromptPay": "",
            "numberPeople": 0,
            "menu": [],
            "menuPrice": {},
            "personPayment": {},
            "totalBath": 0.0,
            "discount": 0.0,
            "taxRate": 0.0,
            "VATable": 0.0
        }

        self.root = root
        self.root.title("Bill Splitter")
        self.root.geometry("500x500")
        self.root.configure(bg="#FFF0F5")

        tk.Label(self.root, text="BillSplitter", font=("Arial", 24), bg="#FFF0F5").pack(pady=20)

        button_frame = tk.Frame(self.root, bg="#FFE4E1")
        button_frame.pack(pady=20, padx=20)

        tk.Button(button_frame, text="ADD DATE", command=self.add_date, bg="#FF69B4", fg="#000080", width=20).grid(row=0, column=0, pady=10)
        tk.Button(button_frame, text="ADD MEMBER", command=self.add_member, bg="#FF69B4", fg="#000080", width=20).grid(row=1, column=0, pady=10)
        tk.Button(button_frame, text="ADD PROMPT PAY", command=self.add_promptpay, bg="#FF69B4", fg="#000080", width=20).grid(row=2, column=0, pady=10)
        tk.Button(button_frame, text="ADD DISH", command=self.add_dish, bg="#FF69B4", fg="#000080", width=20).grid(row=3, column=0, pady=10)
        tk.Button(button_frame, text="ADD VAT", command=self.add_vat, bg="#FF69B4", fg="#000080", width=20).grid(row=4, column=0, pady=10)
        tk.Button(button_frame, text="ADD SERVICE CHARGES", command=self.add_service_charges, bg="#FF69B4", fg="#000080", width=20).grid(row=5, column=0, pady=10)

        tk.Button(self.root, text="Next", command=self.next_screen, bg="#FF69B4", fg="#000080").pack(pady=20)
        tk.Button(self.root, text="View History", command=self.view_history, bg="#FF69B4", fg="#000080").pack(pady=20)

        self.current_screen = None

    def add_date(self):
        self.data["date"] = get_current()
        messagebox.showinfo("Info", f"Date set to {self.data['date']}")

    def add_member(self):
        def save_member():
            self.data["user"] = user_entry.get()
            self.data["numberPeople"] = int(number_people_entry.get())
            add_member_window.destroy()
            messagebox.showinfo("Info", f"User: {self.data['user']}, Number of People: {self.data['numberPeople']}")

        add_member_window = tk.Toplevel()
        add_member_window.title("Add Member")
        add_member_window.configure(bg="#FFF0F5")

        tk.Label(add_member_window, text="User Name:", bg="#FFF0F5").pack(pady=5)
        user_entry = tk.Entry(add_member_window)
        user_entry.pack(pady=5)

        tk.Label(add_member_window, text="Number of People:", bg="#FFF0F5").pack(pady=5)
        number_people_entry = tk.Entry(add_member_window)
        number_people_entry.pack(pady=5)

        tk.Button(add_member_window, text="Save", command=save_member, bg="#FF69B4", fg="#000080").pack(pady=10)

    def add_promptpay(self):
        def save_promptpay():
            self.data["numberPromptPay"] = promptpay_entry.get()
            if not is_valid_promptpay(self.data["numberPromptPay"]):
                messagebox.showerror("Error", "Invalid PromptPay number. Please enter a 10-digit number.")
                return
            add_promptpay_window.destroy()
            messagebox.showinfo("Info", f"PromptPay number set to {self.data['numberPromptPay']}")

        add_promptpay_window = tk.Toplevel()
        add_promptpay_window.title("Add PromptPay")
        add_promptpay_window.configure(bg="#FFF0F5")

        tk.Label(add_promptpay_window, text="PromptPay Number:", bg="#FFF0F5").pack(pady=5)
        promptpay_entry = tk.Entry(add_promptpay_window)
        promptpay_entry.pack(pady=5)

        tk.Button(add_promptpay_window, text="Save", command=save_promptpay, bg="#FF69B4", fg="#000080").pack(pady=10)

    def add_dish(self):
        def save_dish():
            menu_name = menu_name_entry.get()
            menu_price = float(menu_price_entry.get())
            self.data["menu"].append(menu_name)
            self.data["menuPrice"][menu_name] = menu_price
            add_dish_window.destroy()
            messagebox.showinfo("Info", f"Dish added: {menu_name}, Price: {menu_price}")

        add_dish_window = tk.Toplevel()
        add_dish_window.title("Add Dish")
        add_dish_window.configure(bg="#FFF0F5")

        tk.Label(add_dish_window, text="Dish Name:", bg="#FFF0F5").pack(pady=5)
        menu_name_entry = tk.Entry(add_dish_window)
        menu_name_entry.pack(pady=5)

        tk.Label(add_dish_window, text="Price:", bg="#FFF0F5").pack(pady=5)
        menu_price_entry = tk.Entry(add_dish_window)
        menu_price_entry.pack(pady=5)

        tk.Button(add_dish_window, text="Save", command=save_dish, bg="#FF69B4", fg="#000080").pack(pady=10)

    def add_vat(self):
        def save_vat():
            self.data["taxRate"] = float(taxrate_entry.get())
            add_vat_window.destroy()
            messagebox.showinfo("Info", f"VAT rate set to {self.data['taxRate']}%")

        add_vat_window = tk.Toplevel()
        add_vat_window.title("Add VAT")
        add_vat_window.configure(bg="#FFF0F5")

        tk.Label(add_vat_window, text="VAT Rate (%):", bg="#FFF0F5").pack(pady=5)
        taxrate_entry = tk.Entry(add_vat_window)
        taxrate_entry.pack(pady=5)

        tk.Button(add_vat_window, text="Save", command=save_vat, bg="#FF69B4", fg="#000080").pack(pady=10)

    def add_service_charges(self):
        def save_service_charges():
            self.data["discount"] = float(discount_entry.get())
            add_service_charges_window.destroy()
            messagebox.showinfo("Info", f"Service charges set to {self.data['discount']} THB")

        add_service_charges_window = tk.Toplevel()
        add_service_charges_window.title("Add Service Charges")
        add_service_charges_window.configure(bg="#FFF0F5")

        tk.Label(add_service_charges_window, text="Service Charges (THB):", bg="#FFF0F5").pack(pady=5)
        discount_entry = tk.Entry(add_service_charges_window)
        discount_entry.pack(pady=5)

        tk.Button(add_service_charges_window, text="Save", command=save_service_charges, bg="#FF69B4", fg="#000080").pack(pady=10)

    def next_screen(self):
        self.calculate_total()
        display_summary(self.data)

    def calculate_total(self):
        self.data["totalBath"] = sum(self.data["menuPrice"].values())
        total_after_discount = max(0.0, self.data["totalBath"] - self.data["discount"])
        tax_amount = (self.data["taxRate"] / 100.0) * total_after_discount
        self.data["VATable"] = total_after_discount + tax_amount
        self.data["totalBath"] = total_after_discount

        count_participants = self.data["numberPeople"]
        if total_after_discount > 0:
            updated_person_payment = {}
            sum_person = 0.0
            for person, amount in self.data["personPayment"].items():
                tax_share = (amount / total_after_discount) * tax_amount
                new_payment = amount + tax_share
                updated_person_payment[person] = new_payment
                sum_person += new_payment

            diff = self.data["VATable"] - sum_person
            if updated_person_payment:
                last_person = list(updated_person_payment.keys())[-1]
                updated_person_payment[last_person] += diff

            self.data["personPayment"] = updated_person_payment

    def view_history(self):
        display_history(self.history_list)

def main():
    root = tk.Tk()
    app = BillSplitterApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()